package CCOEW;

public enum Location {
PANAJIM,PUNE,DELHI,MUMBAI ;
}
