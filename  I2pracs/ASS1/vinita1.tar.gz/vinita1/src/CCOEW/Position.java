package CCOEW;

public enum Position {
	goalie,fullbacks,goalkeeper;
}
